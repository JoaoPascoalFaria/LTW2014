<?php
ob_start();
session_start();
include('config.php');

if(isset($_SESSION['username']))
	{
		echo 'welcome '.$_SESSION['username'];
	}
	else 
	{
	header("Location: login.php");
	}

?>