<?php
  session_start();
  //abrir ligacao a base de dados
  $db = new PDO('sqlite:user.db');
  
  $username = $_GET['username'];
  $pword = $_GET['pword'];

  $stmt = $db->prepare('SELECT count(IdUser),Permission FROM Utilizador WHERE username = :user AND pword = :pword');
  $stmt->bindParam(':user',$username, PDO::PARAM_STR);
  $stmt->bindParam(':pword',$pword, PDO::PARAM_STR);
  $stmt->execute();
  $result = $stmt->fetch();

if($result[0] == 1)
{
// store session data
$_SESSION['username']=$username;
$_SESSION['Permission']=$result[1];

echo $_SESSION['username'];
echo $_SESSION['Permission'];
//header("Location:welcome.html");
}
else {
echo "Wrong Username or Password";
}
?>