<?php 
include 'checklogin.php';
echo '<html>
<head>
	<title>Poll</title>
</head>
<body> content
<div id="content">
	</div>
</body>
</html>'
?>