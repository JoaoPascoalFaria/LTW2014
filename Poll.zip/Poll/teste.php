<?php include 'checklogin.php'; 
echo '
<html>
	<head>
		Pagina principal
	</head>
	<body onload="log()">
		<script src="jquery-1.10.2.min.js"></script>
		<script>
			function log(){
				var x=document.getElementById("content");
				var d = document.createElement("div");
				x.innerHTML = '';
				 var logstatus='  echo $_SESSION['Permission'];
				 echo ' console.log(logstatus);
				 if(logstatus)
				 {
				 	var lin ='<div id="login">Login\
							<ul><form action="login.php" method="get">\
							<li><p>Username: <input type="text" name=\'username\'/></p></li>\
 							<li><p>Password: <input type="text" name=\'pword\'/></p></li>\
							<li><p><input type="submit"/></p></li>\
							</form></ul></div>';
						x.appendChild(d);
						$(d).append(lin);
				 }
			}
		</script>
	<div id="content">
	</div>
	</body>
</html>'

?>
