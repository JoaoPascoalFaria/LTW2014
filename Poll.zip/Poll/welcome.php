<html>
	<head>
	</head>
	<body >
		<script src="jquery-1.10.2.min.js"></script>
     login redirects here!
		<div id="content">
	</div>
	</body>
</html>	