<?php 
$db = new PDO('sqlite:user.db');
?>